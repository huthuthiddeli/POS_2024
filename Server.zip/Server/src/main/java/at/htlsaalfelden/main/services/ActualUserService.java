package at.htlsaalfelden.main.services;


import at.htlsaalfelden.main.models.Usermodel;
import at.htlsaalfelden.main.repositories.ActualUserRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ActualUserService {
    private final ActualUserRepository repository;

    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private MongoTemplate mongoTemplate;

    @Autowired
    public ActualUserService(ActualUserRepository repo){
        this.repository = repo;
    }

    public List<Usermodel> FindAll(){
        return repository.findAll();
    }

    public Usermodel CreateUser(Usermodel u){
        return repository.save(u);
    }




}
