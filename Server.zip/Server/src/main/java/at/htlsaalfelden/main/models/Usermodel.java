package at.htlsaalfelden.main.models;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "users")
public class Usermodel {

    @Id
    private String id;
    @Field("username")
    private String username;
    @Field("money")
    private int money;
    @Field("passwordHashed")
    private String passwordHashed;

    // Constructors, getters, and setters

    public Usermodel() {
        // Default constructor required by Spring Data MongoDB
    }

    public Usermodel(String username, int money, String passwordHashed) {
        this.username = username;
        this.money = money;
        this.passwordHashed = passwordHashed;
    }

    // Getters and setters for id, username, money, and passwordHashed

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }

    public String getPasswordHashed() {
        return passwordHashed;
    }

    public void setPasswordHashed(String passwordHashed) {
        this.passwordHashed = passwordHashed;
    }
}
