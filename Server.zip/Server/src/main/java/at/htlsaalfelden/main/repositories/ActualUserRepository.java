package at.htlsaalfelden.main.repositories;

import at.htlsaalfelden.main.models.Usermodel;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ActualUserRepository extends MongoRepository<Usermodel, String> {

    Usermodel save(Usermodel save);



}
